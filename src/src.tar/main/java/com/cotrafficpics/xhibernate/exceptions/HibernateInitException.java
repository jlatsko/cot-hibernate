package com.cotrafficpics.xhibernate.exceptions;

public class HibernateInitException extends Exception {
   public HibernateInitException(String msg) {
	   new Exception(msg);
   }
   
}
